from django.shortcuts import render, redirect
from django.http import JsonResponse, HttpResponse
from django.views.decorators.csrf import csrf_exempt
from .medbot.medbot import *  # Import functions

def chat_view(request):
    return render(request, 'chat.html')

def process_user_input(request):
    if request.method == 'POST':
        input_data = request.POST.get('input_data')

        # Save the user input to a list stored in the session
        user_inputs = request.session.get('user_inputs', [])
        user_inputs.append(input_data)
        request.session['user_inputs'] = user_inputs
        bot_response = main1(user_inputs)
        bot_answers = request.session.get('bot_answers', [])
        if bot_response[:11] == "The symptom":
            user_inputs.pop(-1)
            print("We ballin")

        def replace_underscores(inp_string):
            return inp_string.replace('_', ' ')
        
        bot_response = replace_underscores(bot_response)

        bot_answers.append(bot_response)
        request.session['bot_answers'] = bot_answers

        inputs_responses = zip(bot_answers, user_inputs[1:])

        return render(request, 'result_template.html', {'input_data': input_data, 'user_inputs': user_inputs, 'bot_response': bot_response, 'bot_answers': bot_answers, 'inputs_responses': inputs_responses, 'user_name':user_inputs[0], 'greeting':bot_answers[0]})
    else:
        return render(request, 'input_form_template.html')

def display_user_inputs(request):
    user_inputs = request.session.get('user_inputs', [])
    return render(request, 'user_inputs_template.html', {'user_inputs': user_inputs})

def clear_session(request):
    request.session.clear()
    return render(request, 'input_form_template.html')

def see_tac(request):
    return render(request, 'tac.html')

def see_guide(request):
    return render(request, 'guide.html')