from django.urls import path
from . import views
from .views import *

urlpatterns = [
    # Define your app-specific URL patterns here
    # For example, if you have a view called 'chat_view', you can include a URL pattern like this:
    path('', views.chat_view, name='chat_view'),
    path('process/', process_user_input, name='process_user_input'),
    path('display/', display_user_inputs, name='display_user_inputs'),
    path('clear-session/', clear_session, name='clear_session'),
    path('tac/', see_tac, name='see_tac'),
    path('guide/', see_guide, name='see_guide'),
]
