import pandas as pd
from sklearn import preprocessing
from sklearn.tree import DecisionTreeClassifier, _tree
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.model_selection import cross_val_score
from sklearn.svm import SVC
import csv
import warnings
import re
from myapp import views

warnings.filterwarnings("ignore", category=DeprecationWarning)

# Loading training data
training = pd.read_csv('https://gitlab.computing.dcu.ie/delahue6/2024-ca326-medai/-/raw/main/code/CSV%20files/Training.csv')

reduced_data = training.groupby(training['prognosis']).max()

# Extracting features and labels
cols = training.columns[:-1]
x = training[cols]
y = training['prognosis']

# Label encoding
le = preprocessing.LabelEncoder()
le.fit(y)
y = le.transform(y)

# Splitting the data into training and testing sets
x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.33, random_state=42)

# Creating and training the decision tree classifier
clf1 = DecisionTreeClassifier()
clf = clf1.fit(x_train, y_train)
scores = cross_val_score(clf, x_test, y_test, cv=3)
decision_tree_score = scores.mean()

# Creating and training the support vector machine (SVM) model
model = SVC()
model.fit(x_train, y_train)
svm_score = model.score(x_test, y_test)

# Feature importance
importances = clf.feature_importances_
indices = np.argsort(importances)[::-1]
features = cols

# Creating Dictionaries
severityDictionary = dict()
description_list = dict()
precautionDictionary = dict()

symptoms_dict = {}

# Mapping symptoms to their indices
for index, symptom in enumerate(x):
    symptoms_dict[symptom] = index


# This is the method that handles the
# list of previously entered user inputs
class ListInputProgram:   
    def __init__(self, input_list):
        
        self.input_list = input_list.copy()

    def __getitem__(self, key):
        
        # Support slicing and indexing
        if isinstance(key, slice):
            # Return a new instance of ListInputProgram if it's a slice
            return ListInputProgram(self.input_list[key])
        elif isinstance(key, int):
            # Return a specific item for an index
            return self.input_list[key]
        else:
            raise TypeError("Invalid argument type.")
    
    def __len__(self):
        
        # Support len() function
        return len(self.input_list)

    # When we call get_input.input_program(), it returns the latest element and then pops
    # it so that the program is ready to input the next user_input
    def get_input(self):
        
        if not self.input_list:
            return None
        if len(self.input_list) == 0:
            return None
        if len(self.input_list) > 0:
            return str(self.input_list.pop(0))
        else:
            return("we got em")

#This is the function that tells people if they should possible see a doctor
def calc_condition(exp, days):
    
    sum_val = sum(severityDictionary[item] for item in exp)
    if (sum_val * days) / (len(exp) + 1) > 10:
        return "You should probably go see a doctor."
    else:
        return "It does not sound too serious, but you should monitor the symptoms"


# GetDescription, Get SeverityDict and getprecautionDict are all here to initialize variables

def getDescription():
    
    global description_list
    description_list = {}
    csv_file = pd.read_csv(
        'https://gitlab.computing.dcu.ie/delahue6/2024-ca326-medai/-/raw/main/code/CSV%20files/symptom_Description.csv?ref_type=heads')
    try:
        for _, row in csv_file.iterrows():
            symptom = row[0]
            description = row[1]
            description_list[symptom] = description
    except:
        pass

def getSeverityDict():
    
    global severityDictionary
    severityDictionary = {}
    csv_file = pd.read_csv(
        'https://gitlab.computing.dcu.ie/delahue6/2024-ca326-medai/-/raw/main/code/CSV%20files/Symptom_severity.csv?ref_type=heads')
    try:
        for _, row in csv_file.iterrows():
            symptom = row[0]
            severity = int(row[1])
            severityDictionary[symptom] = severity
    except:
        pass

def getprecautionDict():
    
    global precautionDictionary
    precautionDictionary = {}
    csv_file = pd.read_csv(
        'https://gitlab.computing.dcu.ie/delahue6/2024-ca326-medai/-/raw/main/code/CSV%20files/symptom_precaution.csv?ref_type=heads')
    try:
        for _, row in csv_file.iterrows():
            symptom = row[0]
            precautions = [row[1], row[2], row[3], row[4]]
            precautionDictionary[symptom] = precautions
    except:
        pass


# This is what matches the first inputted symptom to a valid symptom
# It also replaces " " with "_", which is important for regular expressions (regexp)
def check_pattern(dis_list, inp):
    
    pred_list = []
    inp = inp.replace(' ', '_')
    patt = f"{inp}"
    regexp = re.compile(patt)
    pred_list = [item for item in dis_list if regexp.search(item)]
    if len(pred_list) > 0:
        return True, pred_list
    else:
        return False, []


# This is a secondary function that takes the given symptoms, and starts at a different point 
# than the initial classifier due to random_state = 20 instead of 42
# If you answer "no" many times, there is not much data to work off of and the prediction is inaccurate
def sec_predict(symptoms_exp):
    
    df = pd.read_csv('https://gitlab.computing.dcu.ie/delahue6/2024-ca326-medai/-/raw/main/code/CSV%20files/Training.csv')
    X = df.iloc[:, :-1]
    y = df['prognosis']
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=20)
    rf_clf = DecisionTreeClassifier()
    rf_clf.fit(X_train, y_train)

    symptoms_dict = {symptom: index for index, symptom in enumerate(X)}
    input_vector = np.zeros(len(symptoms_dict))
    for item in symptoms_exp:
        input_vector[[symptoms_dict[item]]] = 1

    return rf_clf.predict([input_vector])


# This is the main function in this code where the work is executed
# It is called recursively with the input list "input_program"
def tree_to_code(tree, feature_names, input_program):
    
    diagnosis = ""
    tree_ = tree.tree_


    #Here we are populating our Decision Tree 
    feature_name = [
        feature_names[a] if a != _tree.TREE_UNDEFINED else "undefined!"
        for a in tree_.feature
    ]


    chk_dis = ",".join(feature_names).split(",")
    symptoms_present = []
    
    
    #This is where we take the input for the users name
    while True:
        try:
            name = input_program.get_input()
            print(name)
            break
        except:
            return("What is your name?")
        
        
    # This is where we take input for the initial symptom. 
    # It features the pattern matching from check_pattern so that users
    # cannot enter invalid symptoms, instead it will give a list of valid symptoms to choose from
    while True:
        try:
            invflag = ""
            disease_input = input_program.get_input()
            if disease_input == None:
                return ("Hello, " + name + ". What is the main symptom you are experiencing?")
            conf, cnf_dis = check_pattern(chk_dis, disease_input)
            if conf==1:
                invflag += "Searches related to input"
                for num, it in enumerate(cnf_dis):
                    invflag += " " + str(num) + ")" + str(it)
                if num != 0:
                    invflag += "Select the one you meant (0 - " + str(num) + ")"
                    conf_inp = input_program.get_input()
                else:
                    conf_inp = 0
                break
            else:
                valid_symptoms_suggestions = ", ".join(chk_dis)
                invflag += f"The symptom you entered ('{disease_input}') is not recognized. Please enter a valid symptom. Suggestions: {valid_symptoms_suggestions}"
        except IndexError:
            return("Enter the main symptom you are experiencing")
        return invflag
           
    # Here is where we take input for the number of says someonme has been sick
    while True:
        try:
            num_days = int(input_program.get_input())
            break
        except TypeError:
            return("For how many days have you been experiencing this symptom? Please enter a number.")
        except ValueError:
            input_program = input_program [:-1]
            return("For how many days have you been experiencing this symptom? Please enter a number.")

        
    # This is the recursive function that traverses the Decision Tree until it finds a disease 
    # that has the same symptom as "disease_input"
    def recurse(node, depth):
        
        
        nonlocal symptoms_present
        nonlocal diagnosis
        
        #This part of the recurse function traverses a tree until it finds a leaf-node. Then it breaks
        if tree_.feature[node] != _tree.TREE_UNDEFINED:
            
            name = feature_name[node]
            threshold = tree_.threshold[node]

            if name == disease_input:
                val = 1
            else:
                val = 0
            if val <= threshold:
                recurse(tree_.children_left[node], depth + 1)
            else:
                symptoms_present.append(name)
                recurse(tree_.children_right[node], depth + 1)
        
        
        #This part of the code handles the input for the Yes/No questions
        else:
            
            present_disease = print_disease(tree_.value[node], le)
            red_cols = reduced_data.columns
            symptoms_given = red_cols[reduced_data.loc[present_disease].values[0].nonzero()]
            symptoms_exp = []
            j = 0
            syms = list(symptoms_given)
            
            #If this loop gets broken, the program will finish. Otherwise, it will register the input as:
            while j <= len(syms):
                global i
                i = syms[j]
                answer = input_program.get_input()
                if answer == "yes":
                    symptoms_exp.append(syms[j])
                    j = j + 1
                    if j < len(syms):
                        i = syms[j]
                    else:      
                        #print("CRASH")
                        break
                    
                elif answer == None:
                    i = syms[j]
                    j = j + 1
                    #print("NONE")
                    return i
                elif answer == "no":
                    i = syms[j-1]
                    j = j + 1
                    #print("NO")

                else:
                    #print("INVALID")
                    i = "Please only enter yes or no"
                
            second_prediction = sec_predict(symptoms_exp)
            print(calc_condition(symptoms_exp, num_days))
            if present_disease[0] == second_prediction[0]:
                diagnosis = ("You may have " + present_disease[0] + ". " + description_list[present_disease[0]])
            else:
                diagnosis = ("You may have " + present_disease[0] + " or " + second_prediction[0] + "\n" + description_list[present_disease[0]] + "\n" + description_list[second_prediction[0]])

            precution_list = precautionDictionary[present_disease[0]]
            diagnosis += (" Take the following measures: ")
            for n, p in enumerate(precution_list):
                diagnosis += str((n + 1, "-", p))


    recurse(0, 1)
    if diagnosis:
        return diagnosis
    else:
        fallback_message = ("Are you experiencing any " + str(i) + "? Please reply with (yes/no) only.")
        return fallback_message


def print_disease(node, le):
    try:
        node = node[0]
        val = node.nonzero()
        disease = le.inverse_transform(val[0])
        return(disease)
    except(ValueError, KeyError, IndexError):
        return("") 



def main1(user_inputs):
    #user_responses = ["cough", "5", "yes", "yes", "yes"]
    program = ListInputProgram(user_inputs)
    getSeverityDict()
    getDescription()
    getprecautionDict()
    result = tree_to_code(clf, cols, program)
    return result